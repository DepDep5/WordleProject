public class PreviousGuesses {
    
    private String[] Guesses = {"", "", "", "", "", ""};
    private int nums;
    private int numWrongGuesses;
    private int guessesMade;
    private String[] HangmanImage = {"This is the same wordle on the Internet\n"+
                                "letters with # next to it means it is in the word with the wrong position\n"+
                                "letters with ! next to it means that it is in the word in the right position\n"+
                                "Good Luck!\n"+
                                "There are no Repeating Letters",

                                "Previous Guesses\n" + "5 Guesses left",
                            
                                "Previous Guesses\n" + "4 Guesses left",
                            
                                "Previous Guesses\n" + "3 Guesses left",
                                
                                "Previous Guesses\n" + "2 Guesses left",
                                
                                "Previous Guesses\n" + "1 Guess left",
                                
                                "Previous Guesses\n",
                            };
    private String[] Errors = { "Keep Going", "Invalid Length, Try Again", "Not A Word, Try Again"};
   public PreviousGuesses() {
    }
    public void previousGuesses(String str) {
        for(int i = Guesses.length - 1; i >= 0; i--) {
            if (!str.equals("nullLength") && !str.equals("nullWord") && Guesses[i].equals("")) {
                Guesses[i] = str;
                System.out.println(Guesses[i]);
                guessesMade++;
                i = -1;
                nums = 0;
                guessesLeft();
            }
        }
        if (str.equals("nullLength")) {
            nums = 1;
        }
        if (str.equals("nullWord")) {
            nums = 2;
        }
    }

   public void show() {
       System.out.println(HangmanImage[numWrongGuesses]);
       System.out.println(Guesses[5]);
       System.out.println(Guesses[4]);
       System.out.println(Guesses[3]);
       System.out.println(Guesses[2]);
       System.out.println(Guesses[1]);
       System.out.println(Guesses[0]);
       System.out.println(Errors[nums]);
   }
   public void guessesLeft() {
       if (numWrongGuesses <= 5) {
       numWrongGuesses++;
    } else {
        numWrongGuesses = 0;
    }
    }
   public boolean hasNotLoss(int num) {
       return num < 5;
    }
    public int getGuesses() {
        return guessesMade;
    }
}
