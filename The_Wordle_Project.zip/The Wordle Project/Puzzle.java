import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Puzzle
{
    private String puzzleAns;
    private String guess;
    private String display;
    private String guesses;
    private int lettersGuessed;
    public Puzzle() {
        puzzleAns = "DYLAN";
        display = "_____";
        guesses = "Guesses: ";
        lettersGuessed = 0;
    }
    public boolean isUnsolved() {
        String check = "_";
        if (lettersGuessed < puzzleAns.length()) return true;
        return false;
    }
    public void show() {
        System.out.print("Puzzle:");
        System.out.println(display);
        System.out.println(guesses);
    }
    
    public boolean makeGuess(String h) {
        String g = h.toUpperCase();
        boolean Ans = false;
        for (int i = 0; i <= puzzleAns.length() - 1; i++) {
                if (puzzleAns.substring(i, i + 1).equals(g)) {
                    display = display.substring(0, i) + g + display.substring(i+1);
                    System.out.println("Jesus");
                    Ans = true;
                    lettersGuessed++;
                }
        }
       
        guesses += g + ", ";
        return Ans;
    }

    public String getWord() {
        return puzzleAns;
    }
}
