public class adsad {
    public static void main(String args[]) {
        int[] arr = {1, 1, 1, 1, 1, 1};
        int sum = arr[0], i = 0;
        while (i < arr.length) {
            i++;
            sum+=arr[i];
        }
        System.out.println(sum);
    }
}