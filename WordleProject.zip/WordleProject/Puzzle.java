import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Puzzle
{
    private String puzzleAns;
    private ArrayList<String> wordList;
    private String guess;
    private String display;
    private String guesses;
    private int lettersGuessed;
    private int winCondition;
    public Puzzle() {
        wordList = new ArrayList<String>();
        puzzleAns = getPuzzle();
        
        display = "_____";
        guesses = "Guesses: " + puzzleAns; // used for testing
        lettersGuessed = 0;
    }

    public void show() {
        System.out.print("Puzzle:");
        System.out.println(display);
        System.out.println(guesses);
    }

    public String makeGuess(String h) {
        String g = h.toUpperCase();
        String answer = "";
        winCondition = 0;
        if (g.length() != 5) return "nullLength";
        if (!isWord(g)) return "nullWord";
        for (int i = 0; i <= puzzleAns.length() - 1; i++) {
            if (puzzleAns.indexOf(g.substring(i, i + 1)) >= 0) {
                if (g.substring(i, i + 1).equals(puzzleAns.substring(i, i + 1))) {
                    answer+=g.substring(i, i + 1) + "! ";
                    display = display.substring(0, i) + g.substring(i, i + 1) + display.substring(i + 1);
                    winCondition++;
                } else {
                    answer+=g.substring(i, i + 1) + "# ";
                }
            } else {
                answer+=g.substring(i, i + 1) + "  ";
            }
        }
        System.out.println("dsadjsadjkasd" + answer);
        return answer;
    }

    public int getWinCondition() {
        return winCondition;
    }

    public String getWord() {
        return puzzleAns;
    }

    public String getPuzzle() {
        String ans = "";
        try {
            Scanner sc  = new Scanner(new File("words.txt"));
            while (sc.hasNextLine()) {          
                String line = sc.nextLine();
                line.toUpperCase();
                if (checkLine(line)) {
                    wordList.add(line);
                    //System.out.println(line);
                }
            }
            int index = (int) (Math.random() * wordList.size());
            ans = wordList.get(index);
        }
        catch (Exception e) {
            System.out.println("error loading file");
        }
        return ans.toUpperCase();
    }
    public boolean checkLine(String line) {
        if (line.length() != 5) return false;
        line = line.toUpperCase();
        for (int i = 0; i < 5; i++) {
            for (int k = i + 1; k < 5; k++) {
                if (line.substring(i, i + 1).equals(line.substring(k, k + 1))) {
                    return false;
                }
            }
        }
        return true;
    }
    public boolean isWord(String str) {
        try {
            Scanner sc  = new Scanner(new File("words.txt"));
            while (sc.hasNextLine()) {          
                String line = sc.nextLine();
                line = line.toUpperCase();
                if (str.equals(line)) {
                    return true;
                    //System.out.println(line);
                }
            }
            return false;
        } catch (Exception e) {
            System.out.println("error loading file");
        }
        return false;
    }
}


