import java.util.*;

public class WordleGame {
    
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);
        PreviousGuesses previousGuess = new PreviousGuesses();
        Puzzle puzzle = new Puzzle();
        
        while (previousGuess.hasNotLoss(puzzle.getWinCondition()) && previousGuess.getGuesses() < 6) {
            previousGuess.show();
            puzzle.show();
            System.out.print("\nMake a guess: ");
            String guess = scanner.nextLine();
            previousGuess.previousGuesses(puzzle.makeGuess(guess));
            clearScreen();
        }
        
        if (previousGuess.hasNotLoss(puzzle.getWinCondition()) && puzzle.getWinCondition() < 5) {
            System.out.println("You lose! The word was " + puzzle.getWord());
        } else {
            System.out.println("Good Job You Guessed The Word " + puzzle.getWord());
        }
    }
    
    public static void clearScreen() {
        System.out.println("\f");
    }
}

